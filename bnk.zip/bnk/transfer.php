<?php

require_once dirname(__FILE__) . '/jdatetime.class.php';

$date = new jDateTime(true, true, 'Asia/Tehran');


?>
<script>
    function ent() {
  var x = document.getElementById("ent");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }}
    function tener() {
  var x = document.getElementById("tener");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 

 function suc() {
  var x = document.getElementById("suc");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 
function hid(name) {
  var x = document.getElementById(name);
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 
</script>
<html>
    <head>
        <meta charset="utf-8">
    
       
        <link rel="stylesheet" href="https://cdn.rtlcss.com/bootstrap/v4.2.1/css/bootstrap.min.css" integrity="sha384-vus3nQHTD+5mpDiZ4rkEPlnkcyTP+49BhJ4wJeJunw06ZAp+wzzeBPUXr42fi8If" crossorigin="anonymous"></head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <title>انتقال وجه</title>
    <link type="text/css" rel="stylesheet" href="https://cdn.rawgit.com/rastikerdar/vazir-font/v18.0.0/dist/font-face.css">    <style>      *{font-family: Vazir;font-size: 16px;}   </style>
    </head>
    <body >
        <style>
            body {
              background-image: url('bg.jpg');
              background-repeat: no-repeat;
              background-attachment: fixed;
              background-size: cover;
            }
       
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style><style>
table {
 
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
//  background-color: #dddddd;
}
</style>
        <header>
            <nav class="navbar  navbar-expand-lg " style="background-color: rgb(6, 5, 105);">
                <a class="navbar-brand" style="color:white;" href="#">
                    <i class="fa fa-search"></i></a>
               
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
                   
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"  style="color:white;"  ;; href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          سایر خدمات 
                        </a>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" style="color:white;" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          خدمات چک
                        </a>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"  style="color:white;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          خدمات پرداخت  
                        </a>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"  style="color:white;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         تسهیلات
                        </a>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle"  style="color:white;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              خدمات کارت
                            </a>
                     
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"  style="color:white;"  href="./" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          انتقال پول
                        </a>
                     
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle"  style="color:white;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          خدمات حساب
                        </a>
                       
                      </li>
                    
                      </li> 
                  </ul>
                
                </div>
              </nav>
        </header>
        <div class="container">
            <!-- Content here -->

<div class="row mt-5">
        <div class="col-md-8">

            <div  class="card">    <h5  style="color:white; background-color: rgb(6, 5, 105);" class="card-header">کارت به کارت <i class="fa  fa-credit-card"></i>
            </h5> <i style="font-size:20px;margin-left:15px;margin-top:-36px;text-align:left;color:white;" class="fa fa-times"></i>
           
                 
            <div class="alert alert-primary col" style="margin-top:19px;" role="alert">
             <h6>  
                   کاربران گرامی، شما در این قسمت می توانید تا سقف ۶۸۰,۰۰۰,۰۰۰,۰۰۰ ریال به سایر کارتهای بانکی انتقال وجه دهید
           <br>
                   کاربران گرامی، درصورت تمایل می توانید سایر ملی کارت های خود که در لیست زیر نمایش داده نمیشوند را اضافه نمایید.
                <a href="#"><b>تنظیمات کارت</b>
                </a>
            </h6>
            </div>
              <div id="suc" style="display : none;" s class="alert alert-success" role="alert">
انتقال با موفقیت انجام شد
</div>
                
                <div class="card-body">
                    <div id="ent">
                  <h5 id="t1" class="card-title">تایید انتقال کارت به کارت</h5><hr>
               <div class="card-text"></div>
                  <span>
                      صاحب کارت:
                      </span>  <b class="ml-3"> <?php echo $_POST["saheb"] ?> </b><br><br>
                   
                     <span>
                      شماره کارت:
                      </span>  <b class="ml-3"> <?php echo $_POST["cardno"] ?> </b><br><br>
                   
                     <span>
                       شماره حساب:
                      </span>  <b class="ml-3"> <?php echo $_POST["hesabno"] ?> </b><br><br>
                   
                     <span>
                      بانک مقصد: 
                      </span>  <b class="ml-3"> <?php echo $_POST["bankname"] ?> </b><br><br>
                   
                     <span>
                       مبلغ انتقال:
                      </span>  <b class="ml-3"> <?php echo $_POST["price"] ?> ریال
                      </b><br><br>
 <div style="display:none;" id="spn">
                     <span>
                        در تاریخ: 
                      </span>  <b class="ml-3"> <?php echo $date->date("l j F Y H:i"); ?> </b><br><br>
                   
                     <span>
                       شماره پیگیری: 
                      </span>  <b class="ml-3"> <?php echo rand(1111111,9999999); ?> </b><br><br>
                    
                     <span>
                      وضعیت تراکنش: 
                      </span>  <b class="ml-3">موفق </b><br><br>
                   </div>
              
                <b id="en1" class="ml-1">آیا از انتقال وجه اطمینان دارید؟</b><br><br>
                <span style="margin-right:600px;">
                <button onclick="hid('en1');ent();tener();setTimeout(tener, 1500);setTimeout(ent, 1500);setTimeout(hid('spn'), 1500);setTimeout(suc, 1700);hid('ensf');"  class="btn btn-primary ml-2">
                    تایید </button> 
                    <span id="ensf">انصراف</span>
</span>
                </div><br><br></div>
                        <div ><center>
<img id="tener"  src="2.gif" width="100px" style="margin-bottom:280px;display : none;">
</center>
  </div>
              </div>
              
              
              
              
              <br><br><br><br>
          </div>
        

        
        <div class="col-md-4" >

          <div class="card"  style="color:white;" >
            <h5 style="color:white; background-color: rgb(6, 5, 105);" class="card-header">آرمین بهادری <span class="ml-5" style="font-size: 17px; margin-right: -10px;">خوش‌آمدید</span><br><br><br><br></nt></h5>
            <center><img src="./user.png" width="120px" height="120px" style="margin-top:-55px;"></center>
            <div class="card-body" style="color:black;">
              <h5 class="card-title" style="margin-top:-10px;"> <span class="ml-5"> <i style="font-size:30px;color:red;" class="fa ml-5 fa-power-off"></i></span>آخرین ورود</h5> 
              <p class="card-text">یک ربع پیش<span class="ml-5">خروج از حساب کاربری</span></p>
            
            </div>
          </div>
   <div class="card"  style="color:white;" >
            <h5 style="color:white; background-color: rgb(6, 5, 105);" class="card-header"> وضعیت حساب  </h5>
            
            <div class="card-body" style="color:black;">
            <center>
                <button   class="btn btn-primary">بلند مدت</button>
                 <button   class="btn btn-primary">کوتاه مدت</button>
               
              <button id="myBtn"   class="btn btn-primary">جاری</button>
             
              </center>

            </div>
          </div>





          <div class="card"  style="color:white;" >
            <h5 style="color:white; background-color: rgb(6, 5, 105);" class="card-header">حساب های ریالی</h5>
            <span class="nav-item dropdown bg-primary">
              <a class="nav-link dropdown-toggle bg-primary"  style="color:white;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               حساب قرض الحسنه
              </a>
            
            </span>

            <div class="card-body" style="color:black;">
            
             
              <span class="nav-item dropdown bg-light ">
                <a class="nav-link dropdown-toggle text-black"  style="color:black;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                خدمات حساب
                </a>
              </span>
              <span class="nav-item dropdown bg-light ">
                <a class="nav-link dropdown-toggle text-black"  style="color:black;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                انتقال پول
                </a>
              </span>
              <span class="nav-item dropdown bg-light ">
                <a class="nav-link dropdown-toggle text-black"  style="color:black;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                خدمات کارت
                </a>
              </span>
            </div>
          </div>




          <div class="card"  style="color:white;" >
            <h5 style="color:white; background-color: rgb(6, 5, 105);" class="card-header">کارت به کارت</h5>
            
            <div class="card-body" style="color:black;">
            
             
              <span class="nav-item dropdown bg-light ">
                <a class="nav-link dropdown-toggle text-black"  style="color:black;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 مانده کارت
                </a>
              </span>
              <span class="nav-item dropdown bg-light ">
                <a class="nav-link dropdown-toggle text-black"  style="color:black;"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                تاریخچه کارت به کارت 
                </a>
              </span>
              

            </div>
          </div>
<img src="k.png" style="margin-top:0">





        </div>

    </div>
<div id="myModal" class="modal">
   <div class="modal-content bg-primary " style="margin-bottom:-10px;"> </div>  
 
  <!-- Modal content -->
  <div class="modal-content ">
  
    <span class="close ">&times;</span><table>
      
      <center>
      <tr>
    <th>شرح</th>
   <th>توضیح عملیات</th>
       <th>واریز</th>
     
    <th>برداشت</th>
      <th>موجودی حساب</th>
      <th>زمان</th>
      <th>تاریخ</th>
    <th>شماره حساب</th>
    
  
  </tr>
  <tr>
    <td>انتقال آنی از کارت</td>
   <td>بین بانکی</td>
   <td>20,000</td>
   <td></td>
   <td>92,136,224</td>
   <td>19:06:02</td>
   <td>1399/9/1</td>
   <td>0009902626563</td>


  </tr>
  <tr>
         <td>انتقال آنی از کارت</td>
   <td>بین بانکی</td>
   <td>9,000,000</td>
   <td>5,500,000</td>
   <td>80,577,457</td>
   <td>09:02:22</td>
   <td>1399/9/1</td>
   <td>0009902584763</td>

  </tr>
  <tr>
    <td>انتقال آنی از کارت</td>
   <td>بین بانکی</td>
   <td>2,000,000</td>
   <td></td>
   <td>46,346,333</td>
   <td>09:02:22</td>
   <td>1399/8/17</td>
   <td>0009902515563</td>

  </tr>
  <tr>
      <td>انتقال آنی از کارت</td>
   <td>بین بانکی</td>
   <td></td>
   <td>200,000</td>
   <td>22,547,907</td>
   <td>09:02:22</td>
   <td>1399/8/15</td>
   <td>0009902515563</td>

  </tr>
</center>
 
</table>

  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    </body>

</html>
<script>
    ten();
</script>